# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

require_relative "file-system-tests"

class TestSlowFileSystem < Test::Unit::TestCase
  def setup
    Dir.mktmpdir do |tmpdir|
      options = Arrow::LocalFileSystemOptions.new
      local_fs = Arrow::LocalFileSystem.new(options)
      subtree_fs = Arrow::SubTreeFileSystem.new(tmpdir, local_fs)
      @fs = Arrow::SlowFileSystem.new(subtree_fs, 0.001)
      yield
    end
  end

  include FileSystemTests

  def test_type_name
    assert_equal([
                   "slow",
                   "subtree",
                 ],
                 [
                   @fs.type_name,
                   @fs.base_file_system.type_name,
                 ])
  end
end
